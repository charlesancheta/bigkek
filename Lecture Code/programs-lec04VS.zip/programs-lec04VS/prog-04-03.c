/*
 ============================================================================
 Name        : lecture-04.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>


int main(void)
{
	int Jane_age, Alicia_age, Tom_age;

	Jane_age = Alicia_age = Tom_age = 7;

	//...


	printf("                   Jane    Alicia       Tom\n");
	printf("age is (in years): %4d %9d %9d\n", Jane_age, Alicia_age, Tom_age );

return 0; }
