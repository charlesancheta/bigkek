/*
 ============================================================================
 Name        : lecture-03.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARR_SIZE 5

int main(void)
{

	int size, letters;
	char name[ARR_SIZE+1];

	/* this part displays addresses of three variables:
	* an array "name", an integers "size" and "letters"
	* this allows you to see their locations in the memory
	*/
	printf("Address: name %p\n", name);
	printf("Address: size %p\n", &size);
	printf("Address: letters %p\n", &letters);


	/* main program */
	printf("Hi, what is your first name?\n");
	
	/* IMPORTANT !!!
	 * Visual Studio uses scanf_s
	 * it requires the buffer size to be specified for input parameters of type s (string), or c (character)
	
     for example:
	     char value[10];
         scanf_s("%9s", s, _countof(s));
	
         char c;
         scanf_s("%c", &c, 1);
	 */
	scanf_s("%s", name, ARR_SIZE);

	printf("The name is: %s\n", name);
	letters = strlen(name);
	printf("Your first name has %d letters, \n", letters);

	size = sizeof name;
	printf("and we have %d bytes to store it in.\n", size);

	printf("The name is: %s\n", name);

	size = sizeof(double);
	printf("double needs %d\n", size);

	return 0;
}


