/*
 ============================================================================
 Name        : lecture-03.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdio.h>
#include <stdlib.h>

#define ARR_SIZE 20
#define NEG -1

int main(void)
{
	char input_str[ARR_SIZE+1];
	char aux_str[ARR_SIZE+1];

	int int_number = 0;

	float float_number_1 = 0.0;
	float float_number_2 = 0.0;

	/* IMPORTNAT
	* RUN EACH PART individually, especially the first
	* one that illustrates the problem
	*/

	/* the first part that illustrates the problem
	* with scanf("%d", ...) with a non digit entry
	*/
	printf("FIRST PART: problem illustration\n");
	printf("\nEnter integer number: \n");
	
   /* IMPORTANT !!!
    * Visual Studio uses scanf_s
    * it requires the buffer size to be specified for input parameters of type s (string), or c (character)

   for example:
    char value[10];
       scanf_s("%9s", s, _countof(s));

       char c;
       scanf_s("%c", &c, 1);
   */
	
	scanf_s("%d", &int_number);
	printf("You entered floating-point number: %d\n", int_number);

	printf("\nEnter floating-point number: \n");
	scanf_s("%f", &float_number_1);
	printf("You entered floating-point number: %f\n", float_number_1);

	printf("\nEnter floating-point number: \n");
	scanf_s("%s", aux_str, ARR_SIZE);
	scanf_s("%f", &float_number_2);
	printf("You entered floating-point number: %f\n\n", float_number_2);


	/* one of possible solutions
	* you reads anything as a string and then you convert it to a number
	* this solution has a problem with 0
	*/
	printf("\nSECOND PART: first solution (problem with 0)\n");
	printf("Enter 1st integer number: \n");
	scanf_s("%s", input_str, ARR_SIZE);
	int_number = atoi(input_str);

	while (int_number <= 0) {
		printf("Enter 1st integer number again: \n");
		scanf_s("%s", input_str, ARR_SIZE);
		int_number = atoi(input_str);
	}
	printf("You entered 1st integer number: %d\n\n", int_number);


	/* another solution
	* you reads anything as a string and then you convert it to a number
	* this solution solves the problem with 0
	*/
	printf("\nTHIRD PART: second solution (problem with 0 addressed)\n");
	printf("Enter 2nd integer number: \n");
	scanf_s("%s", input_str, ARR_SIZE);
	int_number = atoi(input_str);
	if (int_number == 0 && input_str[0] != '0') {
		int_number = NEG;
	}
	while (int_number < 0) {
		printf("Enter 2nd integer number again: \n");
		scanf_s("%s", input_str, ARR_SIZE);
		int_number = atoi(input_str);
		if (int_number == 0 && input_str[0] != '0') {
			int_number = NEG;
		}
	}
	printf("You entered 2nd integer number: %d\n", int_number);

	return 0;
}
