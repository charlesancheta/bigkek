/*
 ============================================================================
 Name        : lecture-03.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdio.h>

int main(void)
{
	unsigned width, precision;
	int number = 256;
	double weight = 242.5;

	printf("What is the field width?\n");
	
   /* IMPORTANT !!!
    * Visual Studio uses scanf_s
    * it requires the buffer size to be specified for input parameters of type s (string), or c (character)

   for example:
    char value[10];
       scanf_s("%9s", s, _countof(s));

       char c;
       scanf_s("%c", &c, 1);
   */
	
	scanf_s("%d", &width);

	printf("The number is: %*d.\n", width, number);
	printf("Now enter both width and precision\n");

	scanf_s("%d %d", &width, &precision);
	printf("Weight = %*.*f.\n", width, precision, weight);

	return 0;
}
