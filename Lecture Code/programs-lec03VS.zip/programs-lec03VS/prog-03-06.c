/*
 ============================================================================
 Name        : lecture-03.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdio.h>

#define MAX_SIZE 10

int main(void)
{
	int age; float assets;
	char pet[MAX_SIZE+1];

	printf("Enter your age, assets, and favorite pet.\n");

    /* IMPORTANT !!!
     * Visual Studio uses scanf_s
     * it requires the buffer size to be specified for input parameters of type s (string), or c (character)

    for example:
     char value[10];
        scanf_s("%9s", s, _countof(s));

        char c;
        scanf_s("%c", &c, 1);
    */
	
	scanf_s("%d %f", &age, &assets);

	scanf_s("%s", pet, MAX_SIZE);

	printf("age: %d; assets: $%.2f; pet: %s\n", age, assets, pet);

	return 0;
}