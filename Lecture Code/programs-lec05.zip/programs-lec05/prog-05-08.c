/*
 ============================================================================
 Name        : lecture-05.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include <stdio.h>

int main(void)
{
	const int NUMBER = 22;
	int count;

	for(count = 1; count <= NUMBER; count++)
		/* initialization, test, and update */
	{
		printf("Remember to ...\n"); /* action */
	}

	return 0;
}
