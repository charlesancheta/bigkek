/*
 ============================================================================
 Name        : lecture-01.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

int main(void) {

	int num;
	num = 7;

	printf("I am a simple computer.\n");
	printf("My favorite number is %d.\n", num);

	return 0;
}
