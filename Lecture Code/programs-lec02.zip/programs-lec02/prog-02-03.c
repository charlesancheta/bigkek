/*
 ============================================================================
 Name        : lecture-02.c
 Author      : mr
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>

int main(void) {

	int v1 = 4;
	int v2 = 6;

	char letter;

	printf("this is v1/v2 = %d\n", v1/v2);
	letter = 'C';
	//letter = T;
	//letter = "T";

	printf("The code for %c is %d.\n", letter, letter, letter);

	return 0;
}
